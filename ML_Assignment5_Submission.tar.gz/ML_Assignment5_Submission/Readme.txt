For Question-2:
==============
	graph.py
	Assignment5_SVM.py
	dt_func.py
	
    (For Handwriting data set:)
	Run as: python Assignment5_SVM.py -fold 1 handwriting/train.data handwriting/train.labels -test handwriting/test.data handwriting/test.labels > Q3_1_a

	(For Madelon data set: with 5-fold cross validation)
    Run as: python Assignment5_SVM.py -fold 5 madelon/madelon_train.data madelon/madelon_train.labels -test madelon/madelon_test.data madelon/madelon_test.labels > Q3_2

For Question-3.1:
===============
	Assignment_DTs.py
	graph.py
	dt_func.py

	(For Handwriting data set with decision tree ensemble)
	python Assignment_DTs.py -fold 1 handwriting/train.data handwriting/train.labels -test handwriting/test.data handwriting/test.labels > Q3_Ensemble_discrete

For Question-3.2:
=================
	graph_cont.py (modified for continuous data)
	cont_dt_func.py (modified for continuous data)
	Assignment_cont_DTs.py (modified for continuous data)

	(For Madelon data set with decision tree ensemble)
    Run as : python Assignment_cont_DTs.py -fold 1 madelon/madelon_train.data madelon/madelon_train.labels -test madelon/madelon_test.data madelon/madelon_test.labels > Q3_Ensemble_continuous


Q3_1_a : Report for Question3.1.1
Q3_2 : Report for Question3.1.2 and 3.1.3 (k-fold + precision recall)
Q3_Ensemble_discrete : Report for handwriting data set
Q3_Ensemble_continuous_1n : Report across multiple decision tree sets with p=1
Q3_Ensemble_continuous_2n : Report across multiple decision tree sets with p=2
Q3_Ensemble_continuous_5n : Report across multiple decision tree sets with p=5

When you run the run.sh files, the following files will be generated whose details can be found above:
Q3_1_a
Q3_2
Q3_Ensemble_discrete
Q3_Ensemble_continuous (the 1n/2n/5n were samples of experiment kept for gathering the data. The final data you genrate will be 1n)

	
